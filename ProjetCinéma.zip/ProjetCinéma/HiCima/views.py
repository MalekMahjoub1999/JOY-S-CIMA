from django.shortcuts import render
from .models import Film


#on ecrit la logique pour envpoyer les données vers l interface

def home(request):
    list_films=Film.objects.all()
    context={"liste_films":list_films}
    return render(request,"index.html",context)
#importation du données de l'article
def detail(request,id_film):
    film=Film.objects.get(id=id_film)

    return render(request,"detail.html",{"film":film})
